<?php require_once('../../config/connect.php');
    session_start();
?>
<html>
	<head>
		<title>EasyTravels.com</title>
		<link rel="icon" href="../images/favicon.png" type="image/png" />
		<link rel="shortcut icon" href="/favicon.ico" />
	</head>
	<body>
		<?php  header("Location: user_nonhome_page.php");?>
	</body>
</html>
