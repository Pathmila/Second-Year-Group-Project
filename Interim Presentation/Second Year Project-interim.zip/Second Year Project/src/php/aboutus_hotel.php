<?php
    require_once('../../config/connect.php');
    session_start();
?>
<?php require_once('hotel_navigation.php')?> 
<?php include('../../public/html/aboutus_hotel.html')?>
<?php require_once('footer.php')?>

