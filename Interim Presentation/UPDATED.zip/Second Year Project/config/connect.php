<?php

    $servername="localhost";
    $username="root";
    $password=1234;
    $dbname="easytravels";


    $connection=mysqli_connect($servername,$username,$password,$dbname) or die("DB connection failed");

	
?>