<?php require_once('../../config/connect.php');
    session_start();
?>
<?php require_once('admin_topnav.php') ?>
<?php require_once('menu.php') ?>
<?php include('../../public/html/admin_home_page.html')?>
<?php require_once('footer.php')?> 
