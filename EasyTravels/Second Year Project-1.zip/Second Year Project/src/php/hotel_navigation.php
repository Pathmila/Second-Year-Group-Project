<?php include('../../public/html/hotel_navigation.html')?>
