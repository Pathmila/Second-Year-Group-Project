<?php require_once('../../config/connect.php');
    session_start();
?>
<?php require_once('user_nonnavigation.php')?> 
<?php include('app_logic2.php'); ?>
<?php include('../../public/html/pending.html')?>
<?php require_once('footer.php')?>


