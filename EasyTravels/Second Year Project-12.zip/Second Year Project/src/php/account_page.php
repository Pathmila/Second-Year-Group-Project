<?php
    require_once('../../config/connect.php');
    session_start();
?>
<?php require_once('user_nonnavigation.php')?> 
<?php include('../../public/html/account_page.html')?>
<?php require_once('footer.php')?>