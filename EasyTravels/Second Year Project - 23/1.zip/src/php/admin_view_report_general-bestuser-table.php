<?php
	echo"
			<div class='container8'>
			<center><table class='graph'>
				<thead>
					<tr>
						<th scope='col'>User ID</th>
						<th scope='col'>Percent</th>
					</tr>
				</thead>
			<tbody>";
			
	$sql3="select count(packid) from resavation";
	$result3=$connection->query($sql3);
	while($row3=$result3->fetch_assoc()){
		$total=$row3['count(packid)'];
		//echo $total;
	}
				
	$sql="select DISTINCT uid from resavation";
	//echo $sql;
	$result=$connection->query($sql);
	while($row=$result->fetch_assoc()){
		$uid=$row['uid'];
		
		$sql1="select count(packid) from resavation where uid='$uid'";
		//echo $sql1;
		$result1=$connection->query($sql1);
		while($row1=$result1->fetch_assoc()){
			$count=$row1['count(packid)'];					
			$point=($count/$total)*100;
						
			echo"
				<tr style='height:$point%'>
					<th scope='row'>$uid</th>
					<td><span>$point</span></td>
				</tr>";
								
		}
	}
?>