<?php require_once('../../config/connect.php');
    session_start();
 ?>
<?php require_once('user_navigation.php')?> 


<?php include('../../public/html/user_package_for_destination_more_details_page.html')?>
<?php require_once('footer.php')?>