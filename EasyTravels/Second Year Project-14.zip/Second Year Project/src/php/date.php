<?php 
	echo "<br /><div style='font-size:20px; color:white;'>";
	echo date("d/m/Y");
	echo "</div><br />";
?>	