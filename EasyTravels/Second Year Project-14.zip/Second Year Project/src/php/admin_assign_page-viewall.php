<?php require_once('admin_topnav.php') ?>
<?php require_once('menu.php') ?>
<?php require_once('../../config/connect.php');
    
?> 

<?php include('../../public/html/admin_assign_page-viewall.html')?>
