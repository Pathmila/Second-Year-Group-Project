<?php require_once('../../config/connect.php');
    session_start();
?>

<?php include('../../public/html/admin_home_page.html')?>

