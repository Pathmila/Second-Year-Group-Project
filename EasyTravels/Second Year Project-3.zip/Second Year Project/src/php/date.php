<?php 
	echo date("d/m/Y");
	echo "&nbsp";
	echo "&nbsp";
	echo "&nbsp";
	date_default_timezone_set("Asia/Colombo");
	echo date("h:i:sa");
?>	