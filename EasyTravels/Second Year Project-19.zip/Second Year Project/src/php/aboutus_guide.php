<?php
    require_once('../../config/connect.php');
    session_start();
?>
<?php require_once('guide_navigation.php')?> 
<?php include('../../public/html/aboutus_guide.html')?>
<?php require_once('guide_footer.php')?>

