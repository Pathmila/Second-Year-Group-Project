<?php require_once('config/connect.php');
    session_start();
?>
<html>
	<head>
		<title>EasyTravels.com</title>
		<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/icon" href="http://localhost/Second%20Year%20Project/favicon.ico"/>
	</head>
	<body>
		<?php  header("Location: src/php/user_nonhome_page.php");?>
	</body>
</html>
