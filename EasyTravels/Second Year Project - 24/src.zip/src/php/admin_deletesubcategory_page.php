<?php require_once('admin_topnav.php') ?>
<?php require_once('menu.php') ?>
<?php require_once('../../config/connect.php');
    session_start();
    if($_SESSION['admin']!=1){
        header('Location: login_page.php');
    }
	$subcat=$_SESSION['subcategory'];
	//echo $subcat;
 ?>
 <?php	
	$_GLOBAL['subcategory']=0;
	$_GLOBAL['categorysubcategory']=0;
	$_GLOBAL['package']=0;
	$_GLOBAL['packdestination']=0;
	$_GLOBAL['resavation']=0;



	if(isset($_POST['submit'])){
		$subcategory=$_POST['subcat'];
		$sql1="select * from subcategory where name='".$subcategory."'"; 
		//echo $sql;
		$result1 = mysqli_query($connection,$sql1);
		$row1=mysqli_fetch_assoc($result1);
		$subcatid=$row1['subcatid'];
		//echo $catid;


		$number=0;
		$sql13="select * from package where subcatname='".$subcategory."'";
		$result13 = mysqli_query($connection,$sql13);
        while($row13=$result13->fetch_assoc()){
			$packid1=$row13['packid'];
				
			$sql6="select * from resavation where packid='".$packid1."'"; 
			//echo $sql6;
			$result6 = mysqli_query($connection,$sql6);
			$number = mysqli_num_rows($result6);
		}
		if($number == '0'){
			$_GLOBAL['resavation']=1;
		}else{
			$_GLOBAL['resavation']=0;
		}

		//echo $_GLOBAL['resavation'];
		
	}
?>
<?php include('../../public/html/admin_deletesubcategory_page.html')?>
