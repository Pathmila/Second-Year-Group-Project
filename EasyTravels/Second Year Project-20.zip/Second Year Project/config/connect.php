<?php

    $servername="localhost";
    $username="root";
    $password="";
    $dbname="easytravels";


    $connection=mysqli_connect($servername,$username,$password,$dbname) or die("DB connection failed");

	
?>