<?php
	//echo $_SESSION['uid'];
	$sql="select * from assign where vehicle='".$_SESSION['uid']."'";
	//echo $sql;
	$result=mysqli_query($connection,$sql);
	while($row=$result->fetch_assoc()){
			
		echo "<tr>";
		echo "<td align='center'>".$row['package']."</td>";
		echo "<td align='center'>".$row['date']."</td>";
		echo "<td align='center'>".$row['name']."</td>";	
		echo "<td align='center'>0".$row['telephone']."</td>";	
		echo "<td align='center'>".$row['email']."</td>";
		echo "</tr>";
	}
?>