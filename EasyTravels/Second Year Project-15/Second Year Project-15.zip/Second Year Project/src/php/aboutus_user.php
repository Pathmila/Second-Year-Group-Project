<?php
    require_once('../../config/connect.php');
    session_start();
?>
<?php require_once('user_navigation.php')?> 
<?php include('../../public/html/aboutus_user.html')?>
<?php require_once('footer.php')?>

