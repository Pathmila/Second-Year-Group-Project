<?php
	$sql="select * from resavation order by resvid desc";
	//echo $sql;
	$result=$connection->query($sql);
	while($row=$result->fetch_assoc()){
		echo "<tr class='ttext'>";

		echo "<td> <form method='post' action='admin_view_booking_page.php'><input name='viewticket' type='submit' id='next' value='".$row['resvid']."' class='next'>";
		echo "<input type='hidden' name='selectedID' value='".$row['resvid']."'/></form></td>";

		echo "<td>".$row['packid']."</td>";
		echo "<td>".$row['uid']."</td>";
		echo "<td>".$row['date']."</td>";
		echo "<td>".$row['travelers']."</td>";
		echo "<td>".$row['singlerooms']."</td>";
		echo "<td>".$row['doublerooms']."</td>";
		echo "<td>".$row['familyrooms']."</td>";
		echo "</tr>";
	}
?>
