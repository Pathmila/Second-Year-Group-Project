<?php
    require_once('../../config/connect.php');
    session_start();
?>
<?php require_once('vehicle_navigation.php')?> 
<?php include('../../public/html/aboutus_vehicle.html')?>
<?php require_once('footer_vehicle.php')?>

