<?php
	echo"
		<div class='container8'>
			<center><table class='graph'>
				<thead>
					<tr>
						<th scope='col'>Package</th>
						<th scope='col'>Percent</th>
					</tr>
				</thead>
			<tbody>";

	$sql3="select count(packid) from resavation";
	$result3=$connection->query($sql3);
	while($row3=$result3->fetch_assoc()){
		$total=$row3['count(packid)'];
		//echo $total;
	}
	
	$sql3="select DISTINCT packid from resavation order by packid asc";
	//echo $sql3;
	$result3=$connection->query($sql3);
	while($row3=$result3->fetch_assoc()){
		$packid = $row3['packid'];
	
											
		$sql="select name from package where packid='$packid' ";
		//echo $sql;
		$result=$connection->query($sql);
		while($row=$result->fetch_assoc()){					
			//echo "<td>".$row['name']."</td>";				
		}

		$sql1="select count(packid) from resavation where packid ='$packid' ";
		//echo $sql1;
		$result1=$connection->query($sql1);
		while($row1=$result1->fetch_assoc()){
			$count = $row1['count(packid)'];
						
			$point=($count/$total)*100;
						
			echo"
				<tr style='height:$point%'>
					<th scope='row'>$packid</th>
					<td><span>$point</span></td>
				</tr>";
		}			
	}
	echo"</table></div>";
?>