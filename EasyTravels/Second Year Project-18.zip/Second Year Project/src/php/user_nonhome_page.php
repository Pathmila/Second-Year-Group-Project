<?php require_once('user_nonnavigation.php')?>    
<?php 
    require_once('../../config/connect.php');
    session_start();
?>

<?php include('../../public/html/user_nonhome_page.html')?>
<?php require_once('footer.php')?>