<?php require_once('../../config/connect.php');
    session_start();
    if($_SESSION['admin']!=0){
        header('Location: login_page.php');
    }
?>
<?php require_once('user_navigation.php')?> 

<?php 
    $name=$_SESSION['name'];
    $price=$_SESSION['price'];
	$date1=date("d/m/Y");
	$_SESSION['date1']=$date1;
	//echo $_SESSION['date1'];
	$datelike=date("d/m/Y");
	//echo $day;
	$array = explode("/",$datelike);
	$year= $array[2];
	$month= $array[1];
	$day= $array[0];
	
	$today=(String)($month.'/'.$day.'/'.$year);
	//echo $today;
	
	$uname=$_SESSION['username'];
	$password=$_SESSION['pwd'];
	$aid=$_SESSION['aid'];
	//echo $aid;	
	$sql="select * from account where aid='".$aid."' ";
	//echo $sql;
	$result=mysqli_query($connection,$sql);
	while($row=$result->fetch_assoc()){
		$id=(string)$row['uid'];
		//echo $id;	
		$uname=(string)$row['username'];
	}
	
	$sql1="select * from user where uid='".$id."'";
	//echo $sql1;
	$result1=mysqli_query($connection,$sql1);
	while($row1=$result1->fetch_assoc()){       
        $pname=$row1['name'];
        $paddress=$row1['address'];
        $pemail=$row1['email'];
        $ptelephone=$row1['telephone'];
    }
	
?>
<?php
	if(isset($_GET['submit'])){
		$no=$_GET['no'];
		$_SESSION['no']=$no;
		//echo $_SESSION['no'];
		$amount=$price*$no;
		//echo $amount;
		
		$selectday=$_GET['date'];
		//echo $selectday;
		$single=$_GET['single'];
		$double=$_GET['double'];
		$family=$_GET['family'];
		$cname=$_GET['cname'];
		$email=$_GET['email'];
		$phone=$_GET['phone'];
		$address=$_GET['address'];
		
		$checkDateOf= checkDateOf($today,$selectday);
		$checkRooms= checkRooms($no,$single,$double,$family);
		
		if($checkDateOf==0){
			$selectday="";
		}

		if($checkRooms==0){
			$single="0";
			$double="0";
			$family="0";	
		}
				
		if(($checkDateOf==1) && ($checkRooms==1)){	
			//echo "asini";
			$_SESSION['amount']=$amount;
			$_SESSION['date']=$_GET['date'];
			$_SESSION['cname']=$_GET['cname'];
			$_SESSION['email']=$_GET['email'];
			$_SESSION['phone']=$_GET['phone'];
			$_SESSION['address']=$_GET['address'];
				
			$_SESSION['single']=$_GET['single'];
			$_SESSION['double']=$_GET['double'];
			$_SESSION['family']=$_GET['family'];
				
			header("Location: user_destination_payhere_page.php");	
		}
	}
?>

<?php
	function checkDateOf($today,$selectday){
		$td=$today;
		$array1 = explode("/",$td);
		$year1= $array1[2];
		$month1= $array1[0];
		$day1= $array1[1];
		
		$sd=$selectday;
		$array2 = explode("-",$sd);
		$year2= $array2[0];
		$month2= $array2[1];
		$day2= $array2[2];
			
		if((($year1==$year2)&&($month1==$month2)&&($day1<$day2)) || (($year1==$year2)&&($month1<$month2)) || ($year1<$year2) ){
			return 1;
		}else{
			echo "<script> alert('Invalid Date..') </script>";
			return 0;
		}
	}
?>

<?php
	function checkRooms($no,$single,$double,$family){		
		$sr=($single+($double*2)+($family*5));
		//echo $sr;
		if($no<=$sr){
			return 1;
		}else{
			echo "<script> alert('Invalid Number of Rooms..') </script>";
			return 0;			
		}
	}
?>

<?php include('../../public/html/user_destination_book_page.html')?>
<?php require_once('footer_user.php')?>